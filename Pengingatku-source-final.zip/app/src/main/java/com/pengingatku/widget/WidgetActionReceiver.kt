package com.pengingatku.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class WidgetActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_TOGGLE = "com.pengingatku.widget.action.TOGGLE"
        const val EXTRA_ITEM_ID = "item_id"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_TOGGLE) return
        val id = intent.getLongExtra(EXTRA_ITEM_ID, 0L)
        if (id == 0L) return
        val current = TaskStore.find(context, id) ?: return
        val updated = current.copy(enabled = !current.enabled)
        TaskStore.upsert(context, updated)
        AlarmScheduler.schedule(context, updated)
        if (!updated.enabled) AlarmRingService.stopIfMatches(context, id)
        TaskBellWidgetProvider.updateAll(context)
        Toast.makeText(
            context,
            if (updated.enabled) "Alarm aktif · ${updated.timeLabel()}" else "Alarm nonaktif",
            Toast.LENGTH_SHORT
        ).show()
    }
}
