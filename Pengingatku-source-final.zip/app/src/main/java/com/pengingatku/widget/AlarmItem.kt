package com.pengingatku.widget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** A locally stored reminder. No network access is used. */
data class AlarmItem(
    val id: Long,
    val hour: Int,
    val minute: Int,
    val note: String,
    val detail: String,
    val enabled: Boolean
) {
    fun timeLabel(): String = String.format("%02d:%02d", hour, minute)
}

object TaskStore {
    private const val PREFS = "taskbell_local_store"
    private const val KEY_ITEMS = "reminder_items"

    fun load(context: Context): MutableList<AlarmItem> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ITEMS, "[]") ?: "[]"
        val result = mutableListOf<AlarmItem>()
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                result += AlarmItem(
                    id = obj.optLong("id", System.currentTimeMillis() + i),
                    hour = obj.optInt("hour", 8).coerceIn(0, 23),
                    minute = obj.optInt("minute", 0).coerceIn(0, 59),
                    note = obj.optString("note", "Catatan"),
                    detail = obj.optString("detail", ""),
                    enabled = obj.optBoolean("enabled", false)
                )
            }
        } catch (_: Exception) {
            // Keep the app usable if local data is malformed.
        }
        return result.sortedBy { it.id }.toMutableList()
    }

    fun save(context: Context, items: List<AlarmItem>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(JSONObject().apply {
                put("id", item.id)
                put("hour", item.hour)
                put("minute", item.minute)
                put("note", item.note)
                put("detail", item.detail)
                put("enabled", item.enabled)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_ITEMS, array.toString()).apply()
    }

    fun find(context: Context, id: Long): AlarmItem? = load(context).firstOrNull { it.id == id }

    fun upsert(context: Context, item: AlarmItem) {
        val items = load(context)
        val index = items.indexOfFirst { it.id == item.id }
        if (index >= 0) items[index] = item else items.add(item)
        save(context, items)
    }

    fun remove(context: Context, id: Long) {
        save(context, load(context).filterNot { it.id == id })
    }
}
