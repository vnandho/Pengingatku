package com.pengingatku.widget

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Space
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var listContainer: LinearLayout
    private lateinit var permissionContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 11, 12)
        window.navigationBarColor = Color.rgb(11, 11, 12)
        requestNotificationPermissionIfNeeded()
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        if (::listContainer.isInitialized) {
            AlarmScheduler.syncAll(this)
            TaskBellWidgetProvider.updateAll(this)
            renderItems()
            renderPermissions()
        }
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(11, 11, 12))
            isFillViewport = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(content)

        content.addView(TextView(this).apply {
            text = "Pengingatku"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        content.addView(TextView(this).apply {
            text = "Alarm dan catatan sederhana, tersimpan di perangkat"
            textSize = 13f
            setTextColor(Color.rgb(165, 165, 165))
            setPadding(0, dp(5), 0, dp(18))
        })

        val howTo = card()
        howTo.orientation = LinearLayout.VERTICAL
        howTo.setPadding(dp(16), dp(15), dp(16), dp(15))
        howTo.addView(label("Pasang widget di Home Screen", 15f, Color.WHITE, true))
        howTo.addView(label("Tekan lama area kosong layar utama → Widget → Pengingatku.\nKetuk jam atau catatan untuk mengedit. Ketuk bell untuk on/off. Atur ukuran widget dengan menahan widget lalu tarik handle resize launcher.", 12f, Color.LTGRAY).apply {
            setPadding(0, dp(7), 0, 0)
            setLineSpacing(dp(3).toFloat(), 1f)
        })
        content.addView(howTo, marginParams(bottom = 14))

        permissionContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        content.addView(permissionContainer, marginParams(bottom = 14))

        val sectionHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        sectionHeader.addView(label("Daftar alarm", 17f, Color.WHITE, true), LinearLayout.LayoutParams(0, dp(42), 1f))
        sectionHeader.addView(label("OFF / ON", 10f, Color.GRAY))
        content.addView(sectionHeader)

        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listContainer)

        val add = Button(this).apply {
            text = "+  Tambah catatan"
            textSize = 15f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = roundedDrawable(Color.rgb(36, 36, 36), Color.rgb(82, 82, 82), 30)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { tapFeedback(this) { openEditor(null) } }
        }
        content.addView(add, marginParams(top = 8, bottom = 12).apply { height = dp(54) })
        content.addView(label("Widget menampilkan baris sebanyak yang muat pada tinggi widget. Geser catatan ke kiri/kanan di daftar aplikasi untuk menghapus. Resize widget dengan menahan widget lalu tarik handle bawaan launcher.", 11f, Color.GRAY).apply {
            setPadding(dp(2), dp(4), dp(2), 0)
        })

        setContentView(scroll)
        renderPermissions()
        renderItems()
    }

    private fun renderPermissions() {
        permissionContainer.removeAllViews()
        val exactAllowed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
        } else true
        val notificationsAllowed = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (exactAllowed && notificationsAllowed) return

        val panel = card().apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13)) }
        if (!exactAllowed) {
            panel.addView(label("Agar alarm berbunyi tepat waktu", 14f, Color.WHITE, true))
            panel.addView(label("Aktifkan izin “Alarms & reminders” di pengaturan sistem. Tanpa izin ini, Android dapat menunda pengingat.", 11f, Color.LTGRAY).apply {
                setPadding(0, dp(5), 0, dp(8))
            })
            val button = smallButton("Aktifkan alarm tepat") {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                } catch (_: Exception) {
                    Toast.makeText(this, "Buka Info aplikasi → Izin khusus → Alarm & pengingat", Toast.LENGTH_LONG).show()
                }
            }
            panel.addView(button)
        }
        if (!notificationsAllowed) {
            panel.addView(label("Notifikasi alarm belum diizinkan", 13f, Color.WHITE, true).apply {
                setPadding(0, dp(10), 0, dp(4))
            })
            panel.addView(smallButton("Izinkan notifikasi") { requestNotificationPermissionIfNeeded() })
        }
        permissionContainer.addView(panel)
    }

    private fun renderItems() {
        listContainer.removeAllViews()
        val items = TaskStore.load(this)
        if (items.isEmpty()) {
            val empty = card().apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(20), dp(16), dp(20))
            }
            empty.addView(label("Belum ada alarm", 15f, Color.WHITE, true))
            empty.addView(label("Tambahkan catatan pertama lewat tombol di bawah atau langsung dari widget.", 12f, Color.GRAY).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, 0)
            })
            listContainer.addView(empty, marginParams(bottom = 9))
            return
        }

        items.forEach { item ->
            val swipeLayer = FrameLayout(this).apply {
                background = roundedDrawable(Color.rgb(125, 35, 35), Color.rgb(150, 55, 55), 22)
            }
            val reveal = label("HAPUS", 11f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), 0, dp(14), 0)
                alpha = 0f
            }
            swipeLayer.addView(reveal, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END))

            val box = card().apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(12), dp(12))
                isClickable = true
                setOnClickListener { tapFeedback(this) { openEditor(item.id) } }
            }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val time = label(item.timeLabel(), 22f, Color.WHITE, true)
            top.addView(time, LinearLayout.LayoutParams(dp(82), ViewGroup.LayoutParams.WRAP_CONTENT))
            val noteCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            noteCol.addView(label(item.note.ifBlank { "Tanpa catatan" }, 13f, Color.WHITE, true))
            if (item.detail.isNotBlank()) noteCol.addView(label(item.detail, 11f, Color.GRAY).apply { setPadding(0, dp(3), 0, 0) })
            top.addView(noteCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val toggle = Switch(this).apply {
                isChecked = item.enabled
                text = ""
                setOnCheckedChangeListener { _, checked ->
                    val updated = item.copy(enabled = checked)
                    TaskStore.upsert(this@MainActivity, updated)
                    AlarmScheduler.schedule(this@MainActivity, updated)
                    TaskBellWidgetProvider.updateAll(this@MainActivity)
                    renderItems()
                    if (checked) remindExactPermissionIfNeeded()
                }
            }
            top.addView(toggle)
            box.addView(top)
            box.addView(label("Ketuk untuk mengubah · Geser untuk menghapus", 10f, Color.rgb(125, 125, 125)).apply {
                setPadding(dp(82), dp(7), 0, 0)
            })
            swipeLayer.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

            var downX = 0f
            var downY = 0f
            var swiping = false
            var hapticSent = false
            val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
            noteCol.setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                        swiping = false
                        hapticSent = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - downX
                        val dy = event.rawY - downY
                        if (!swiping && kotlin.math.abs(dx) > touchSlop && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.25f) {
                            swiping = true
                        }
                        if (swiping) {
                            box.translationX = dx.coerceIn(-dp(180).toFloat(), dp(180).toFloat())
                            val revealParams = reveal.layoutParams as FrameLayout.LayoutParams
                            revealParams.gravity = if (dx >= 0) Gravity.START or Gravity.CENTER_VERTICAL else Gravity.END or Gravity.CENTER_VERTICAL
                            reveal.layoutParams = revealParams
                            reveal.alpha = (kotlin.math.abs(dx) / dp(105).toFloat()).coerceIn(0f, 1f)
                            if (!hapticSent && kotlin.math.abs(dx) >= dp(105)) {
                                box.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                                hapticSent = true
                            }
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        val dx = event.rawX - downX
                        if (swiping && kotlin.math.abs(dx) >= dp(105)) {
                            box.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                            val direction = if (dx >= 0) 1 else -1
                            box.animate().translationX(direction * (swipeLayer.width + dp(48)).toFloat())
                                .alpha(0f).setDuration(180).withEndAction {
                                    TaskStore.remove(this, item.id)
                                    AlarmScheduler.cancel(this, item.id)
                                    AlarmRingService.stopIfMatches(this, item.id)
                                    TaskBellWidgetProvider.updateAll(this)
                                    swipeLayer.animate().alpha(0f).setDuration(100).withEndAction { renderItems() }.start()
                                }.start()
                        } else {
                            box.animate().translationX(0f).setDuration(170)
                                .setInterpolator(AccelerateDecelerateInterpolator()).start()
                            reveal.animate().alpha(0f).setDuration(120).start()
                            if (!swiping && event.actionMasked == MotionEvent.ACTION_UP) {
                                tapFeedback(box) { openEditor(item.id) }
                            }
                        }
                        true
                    }
                    else -> true
                }
            }
            listContainer.addView(swipeLayer, marginParams(bottom = 9))
        }
    }

    private fun remindExactPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!manager.canScheduleExactAlarms()) renderPermissions()
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1201)
        }
    }

    private fun openEditor(id: Long?) {
        val intent = Intent(this, AlarmEditActivity::class.java)
        if (id != null) intent.putExtra(AlarmEditActivity.EXTRA_ITEM_ID, id)
        intent.putExtra(AlarmEditActivity.EXTRA_MODE, if (id == null) AlarmEditActivity.MODE_NEW else AlarmEditActivity.MODE_EDIT)
        startActivity(intent)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        background = roundedDrawable(Color.rgb(27, 27, 28), Color.rgb(61, 61, 61), 22)
    }

    private fun label(textValue: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private fun smallButton(textValue: String, action: () -> Unit): Button = Button(this).apply {
        text = textValue
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = roundedDrawable(Color.rgb(47, 47, 47), Color.rgb(90, 90, 90), 18)
        setOnClickListener { tapFeedback(this) { action() } }
    }

    private fun roundedDrawable(fill: Int, stroke: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
        setStroke(dp(1), stroke)
    }

    private fun marginParams(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(top)
            bottomMargin = dp(bottom)
        }

    private fun tapFeedback(view: View, action: () -> Unit) {
        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        view.animate().cancel()
        view.animate().scaleX(0.975f).scaleY(0.975f).setDuration(75)
            .setInterpolator(AccelerateDecelerateInterpolator()).withEndAction {
                view.animate().scaleX(1f).scaleY(1f).setDuration(115)
                    .setInterpolator(AccelerateDecelerateInterpolator()).withEndAction { action() }.start()
            }.start()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
