package com.pengingatku.widget

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/** Plays the system alarm tone in a foreground service until the user stops it. */
class AlarmRingService : Service() {
    companion object {
        const val ACTION_STOP = "com.pengingatku.widget.action.STOP_RINGING"
        const val EXTRA_ITEM_ID = "item_id"
        private const val CHANNEL_ID = "taskbell_ringing_alarm"
        private const val NOTIFICATION_ID = 7401
        @Volatile var activeItemId: Long? = null
            private set

        fun stopIfMatches(context: Context, itemId: Long) {
            if (activeItemId == itemId) {
                context.stopService(Intent(context, AlarmRingService::class.java))
            }
        }
    }

    private var ringtone: Ringtone? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            val requestedId = intent.getLongExtra(EXTRA_ITEM_ID, 0L)
            if (requestedId == 0L || activeItemId == requestedId) {
                stopRinging()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            return START_NOT_STICKY
        }

        val id = intent?.getLongExtra(EXTRA_ITEM_ID, 0L) ?: 0L
        val item = if (id != 0L) TaskStore.find(this, id) else null
        if (item == null || !item.enabled) {
            stopSelf()
            return START_NOT_STICKY
        }

        activeItemId = item.id
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification(item))
        startRingtone()
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Pengingatku · Alarm berbunyi",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Alarm aktif sampai dihentikan oleh pengguna"
                    setSound(null, null)
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 500, 300, 500, 300, 800)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    private fun buildNotification(item: AlarmItem): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this, 7410,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, AlarmStopReceiver::class.java).apply {
            action = AlarmStopReceiver.ACTION_STOP
            data = Uri.parse("taskbell://stop/${item.id}")
            putExtra(AlarmStopReceiver.EXTRA_ITEM_ID, item.id)
        }
        val stopPending = PendingIntent.getBroadcast(
            this,
            (item.id xor 0x5AA55AA5L).toInt(),
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = item.detail.ifBlank { "Alarm ${item.timeLabel()} · Ketuk Matikan saat selesai" }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setPriority(Notification.PRIORITY_MAX)
        }
        return builder
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(item.note.ifBlank { "Pengingatku" })
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openPending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(android.R.drawable.ic_media_pause, "Matikan alarm", stopPending)
            .build()
    }

    private fun startRingtone() {
        stopRingtoneOnly()
        val uri: Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        ringtone = RingtoneManager.getRingtone(this, uri)?.also { tone ->
            tone.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) tone.isLooping = true
            tone.play()
        }
        try {
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Pengingatku:AlarmRing").apply {
                setReferenceCounted(false)
                acquire(10 * 60 * 1000L)
            }
        } catch (_: Exception) {
            // Audio playback can still proceed if the device rejects a wake lock.
        }
    }

    private fun stopRingtoneOnly() {
        try { ringtone?.stop() } catch (_: Exception) { }
        ringtone = null
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) { }
        wakeLock = null
    }

    private fun stopRinging() {
        stopRingtoneOnly()
        activeItemId = null
    }

    override fun onDestroy() {
        stopRinging()
        super.onDestroy()
    }
}
