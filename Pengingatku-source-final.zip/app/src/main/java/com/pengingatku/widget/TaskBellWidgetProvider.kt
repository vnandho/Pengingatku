package com.pengingatku.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.RemoteViews

class TaskBellWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id -> updateOne(context, manager, id) }
    }

    companion object {
        private val rowIds = intArrayOf(R.id.row_1, R.id.row_2, R.id.row_3, R.id.row_4, R.id.row_5, R.id.row_6, R.id.row_7, R.id.row_8, R.id.row_9, R.id.row_10)
        private val timeTapIds = intArrayOf(R.id.tap_time_1, R.id.tap_time_2, R.id.tap_time_3, R.id.tap_time_4, R.id.tap_time_5, R.id.tap_time_6, R.id.tap_time_7, R.id.tap_time_8, R.id.tap_time_9, R.id.tap_time_10)
        private val noteTapIds = intArrayOf(R.id.tap_note_1, R.id.tap_note_2, R.id.tap_note_3, R.id.tap_note_4, R.id.tap_note_5, R.id.tap_note_6, R.id.tap_note_7, R.id.tap_note_8, R.id.tap_note_9, R.id.tap_note_10)
        private val bellTapIds = intArrayOf(R.id.tap_bell_1, R.id.tap_bell_2, R.id.tap_bell_3, R.id.tap_bell_4, R.id.tap_bell_5, R.id.tap_bell_6, R.id.tap_bell_7, R.id.tap_bell_8, R.id.tap_bell_9, R.id.tap_bell_10)
        private val timeIds = intArrayOf(R.id.time_1, R.id.time_2, R.id.time_3, R.id.time_4, R.id.time_5, R.id.time_6, R.id.time_7, R.id.time_8, R.id.time_9, R.id.time_10)
        private val noteIds = intArrayOf(R.id.note_1, R.id.note_2, R.id.note_3, R.id.note_4, R.id.note_5, R.id.note_6, R.id.note_7, R.id.note_8, R.id.note_9, R.id.note_10)
        private val detailIds = intArrayOf(R.id.detail_1, R.id.detail_2, R.id.detail_3, R.id.detail_4, R.id.detail_5, R.id.detail_6, R.id.detail_7, R.id.detail_8, R.id.detail_9, R.id.detail_10)
        private val bellIds = intArrayOf(R.id.bell_1, R.id.bell_2, R.id.bell_3, R.id.bell_4, R.id.bell_5, R.id.bell_6, R.id.bell_7, R.id.bell_8, R.id.bell_9, R.id.bell_10)
        private val activeBarIds = intArrayOf(R.id.active_bar_1, R.id.active_bar_2, R.id.active_bar_3, R.id.active_bar_4, R.id.active_bar_5, R.id.active_bar_6, R.id.active_bar_7, R.id.active_bar_8, R.id.active_bar_9, R.id.active_bar_10)

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, TaskBellWidgetProvider::class.java)
            manager.getAppWidgetIds(component).forEach { updateOne(context, manager, it) }
        }

        private fun editPendingIntent(context: Context, id: Long?, mode: String): PendingIntent {
            val intent = Intent(context, AlarmEditActivity::class.java).apply {
                action = "com.pengingatku.widget.EDIT.$mode.${id ?: "new"}"
                data = Uri.parse("taskbell://edit/${id ?: "new"}/$mode")
                if (id != null) putExtra(AlarmEditActivity.EXTRA_ITEM_ID, id)
                putExtra(AlarmEditActivity.EXTRA_MODE, mode)
            }
            val requestCode = ((id ?: 0L).toInt() * 31) + mode.hashCode()
            return PendingIntent.getActivity(
                context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun togglePendingIntent(context: Context, id: Long): PendingIntent {
            val intent = Intent(context, WidgetActionReceiver::class.java).apply {
                action = WidgetActionReceiver.ACTION_TOGGLE
                data = Uri.parse("taskbell://toggle/$id")
                putExtra(WidgetActionReceiver.EXTRA_ITEM_ID, id)
            }
            return PendingIntent.getBroadcast(
                context, (id xor 0x13579BDFL).toInt(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_taskbell)
            val options = manager.getAppWidgetOptions(widgetId)
            val minHeightDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
            val maxHeightDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
            val heightDp = listOf(minHeightDp, maxHeightDp).filter { it > 0 }.maxOrNull() ?: 390
            // Each row uses 60dp height + 5dp gap. Reserve room for padding and the + panel.
            // The widget shows only rows that fit its actual launcher-provided height.
            val rowsThatFit = ((heightDp - 60).coerceAtLeast(65) / 65).coerceIn(1, rowIds.size)
            val items = TaskStore.load(context).take(rowsThatFit)
            views.setViewVisibility(R.id.empty_state, if (items.isEmpty()) View.VISIBLE else View.GONE)

            for (index in rowIds.indices) {
                if (index >= items.size) {
                    views.setViewVisibility(rowIds[index], View.GONE)
                    continue
                }
                val item = items[index]
                views.setViewVisibility(rowIds[index], View.VISIBLE)
                views.setTextViewText(timeIds[index], item.timeLabel())
                views.setTextViewText(noteIds[index], item.note.ifBlank { "Tanpa catatan" })
                views.setTextViewText(detailIds[index], item.detail)
                views.setViewVisibility(detailIds[index], if (item.detail.isBlank()) View.GONE else View.VISIBLE)
                views.setImageViewResource(
                    bellIds[index],
                    if (item.enabled) R.drawable.ic_bell_on else R.drawable.ic_bell_off
                )
                views.setViewVisibility(activeBarIds[index], if (item.enabled) View.VISIBLE else View.GONE)
                views.setOnClickPendingIntent(timeTapIds[index], editPendingIntent(context, item.id, AlarmEditActivity.MODE_TIME))
                views.setOnClickPendingIntent(noteTapIds[index], editPendingIntent(context, item.id, AlarmEditActivity.MODE_EDIT))
                views.setOnClickPendingIntent(bellTapIds[index], togglePendingIntent(context, item.id))
            }

            views.setOnClickPendingIntent(R.id.add_button, editPendingIntent(context, null, AlarmEditActivity.MODE_NEW))
            manager.updateAppWidget(widgetId, views)
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: android.os.Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        updateOne(context, appWidgetManager, appWidgetId)
    }
}
