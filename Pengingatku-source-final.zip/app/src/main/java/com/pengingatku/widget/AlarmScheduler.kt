package com.pengingatku.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import java.util.Calendar

object AlarmScheduler {
    const val ACTION_FIRE = "com.pengingatku.widget.action.FIRE_ALARM"

    private fun firePendingIntent(context: Context, itemId: Long): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_FIRE
            data = Uri.parse("taskbell://alarm/$itemId")
            putExtra(AlarmReceiver.EXTRA_ITEM_ID, itemId)
        }
        return PendingIntent.getBroadcast(
            context,
            (itemId xor (itemId ushr 32)).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun cancel(context: Context, itemId: Long) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        manager.cancel(firePendingIntent(context, itemId))
    }

    fun schedule(context: Context, item: AlarmItem) {
        cancel(context, item.id)
        if (!item.enabled) return

        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, item.hour)
            set(Calendar.MINUTE, item.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
        }
        val triggerAt = next.timeInMillis
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val operation = firePendingIntent(context, item.id)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
                // Fallback keeps the reminder scheduled, but Android may delay it.
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, operation)
            } else {
                val openApp = Intent(context, MainActivity::class.java)
                val showIntent = PendingIntent.getActivity(
                    context,
                    (item.id xor 0x55AA55AAL).toInt(),
                    openApp,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                manager.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, showIntent), operation)
            }
        } catch (_: SecurityException) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, operation)
        }
    }

    fun syncAll(context: Context) {
        TaskStore.load(context).forEach { schedule(context, it) }
    }
}
