package com.pengingatku.widget

import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class AlarmEditActivity : Activity() {
    companion object {
        const val EXTRA_ITEM_ID = "item_id"
        const val EXTRA_MODE = "edit_mode"
        const val MODE_NEW = "new"
        const val MODE_EDIT = "edit"
        const val MODE_TIME = "time"
    }

    private var itemId: Long = 0L
    private var hour: Int = 8
    private var minute: Int = 0
    private var isExisting = false
    private lateinit var noteInput: EditText
    private lateinit var detailInput: EditText
    private lateinit var timeButton: TextView
    private lateinit var activeSwitch: Switch
    private lateinit var deleteButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 11, 12)
        window.navigationBarColor = Color.rgb(11, 11, 12)

        itemId = intent.getLongExtra(EXTRA_ITEM_ID, 0L)
        val existing = if (itemId != 0L) TaskStore.find(this, itemId) else null
        isExisting = existing != null
        if (existing != null) {
            hour = existing.hour
            minute = existing.minute
        } else {
            val now = Calendar.getInstance().apply { add(Calendar.MINUTE, 1) }
            hour = now.get(Calendar.HOUR_OF_DAY)
            minute = now.get(Calendar.MINUTE)
        }

        buildScreen(existing)
        if (intent.getStringExtra(EXTRA_MODE) == MODE_TIME) {
            timeButton.post { showTimePicker() }
        }
    }

    private fun buildScreen(existing: AlarmItem?) {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(11, 11, 12)); isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(25), dp(20), dp(28))
        }
        scroll.addView(content)
        content.addView(TextView(this).apply {
            text = if (isExisting) "Edit catatan" else "Catatan baru"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        content.addView(TextView(this).apply {
            text = "Atur jam, isi catatan, lalu aktifkan bell."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, dp(5), 0, dp(22))
        })

        content.addView(fieldLabel("JAM ALARM"))
        timeButton = TextView(this).apply {
            text = formatTime()
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = roundedDrawable(Color.rgb(32, 32, 32), Color.rgb(83, 83, 83), 22)
            setOnClickListener { tapFeedback(this) { showTimePicker() } }
        }
        content.addView(timeButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(78)).apply { bottomMargin = dp(20) })

        content.addView(fieldLabel("CATATAN"))
        noteInput = editField("Contoh: mengerjakan tugas skill chat", existing?.note ?: "")
        noteInput.maxLines = 2
        content.addView(noteInput, fieldParams())

        content.addView(fieldLabel("DETAIL TAMBAHAN (OPSIONAL)"))
        detailInput = editField("Contoh: email, lokasi, atau keterangan lain", existing?.detail ?: "")
        detailInput.maxLines = 2
        content.addView(detailInput, fieldParams())

        val alarmCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(15), dp(10), dp(12), dp(10))
            background = roundedDrawable(Color.rgb(27, 27, 28), Color.rgb(61, 61, 61), 20)
        }
        val alarmText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        alarmText.addView(TextView(this).apply { text = "Aktifkan alarm"; textSize = 15f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        alarmText.addView(TextView(this).apply { text = "Berulang setiap hari saat aktif"; textSize = 11f; setTextColor(Color.GRAY); setPadding(0, dp(3), 0, 0) })
        alarmCard.addView(alarmText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        activeSwitch = Switch(this).apply { isChecked = existing?.enabled ?: false }
        alarmCard.addView(activeSwitch)
        content.addView(alarmCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(68)).apply { topMargin = dp(7); bottomMargin = dp(20) })

        val saveButton = Button(this).apply {
            text = "Simpan"
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.BLACK)
            background = roundedDrawable(Color.rgb(205, 255, 126), Color.rgb(205, 255, 126), 20)
            setOnClickListener { tapFeedback(this) { saveItem() } }
        }
        content.addView(saveButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)).apply { bottomMargin = dp(10) })

        deleteButton = Button(this).apply {
            text = "Hapus catatan"
            isAllCaps = false
            textSize = 13f
            setTextColor(Color.rgb(255, 140, 140))
            background = roundedDrawable(Color.rgb(30, 20, 20), Color.rgb(90, 50, 50), 18)
            visibility = if (isExisting) View.VISIBLE else View.GONE
            setOnClickListener { confirmDelete() }
        }
        content.addView(deleteButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        content.addView(TextView(this).apply {
            text = "Catatan tersimpan di perangkat. Tidak perlu koneksi internet."
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, 0)
        })
        setContentView(scroll)
    }

    private fun saveItem() {
        val note = noteInput.text?.toString()?.trim().orEmpty()
        if (note.isBlank()) {
            noteInput.error = "Isi catatan terlebih dahulu"
            noteInput.requestFocus()
            return
        }
        if (itemId == 0L) itemId = System.currentTimeMillis()
        val item = AlarmItem(
            id = itemId,
            hour = hour,
            minute = minute,
            note = note,
            detail = detailInput.text?.toString()?.trim().orEmpty(),
            enabled = activeSwitch.isChecked
        )
        TaskStore.upsert(this, item)
        AlarmScheduler.schedule(this, item)
        TaskBellWidgetProvider.updateAll(this)
        Toast.makeText(this, "Catatan disimpan", Toast.LENGTH_SHORT).show()

        val needsExactPermission = item.enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !(getSystemService(ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
        if (needsExactPermission) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                Toast.makeText(this, "Aktifkan Alarm & pengingat melalui Info aplikasi", Toast.LENGTH_LONG).show()
            }
        }
        finish()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("Hapus catatan?")
            .setMessage("Alarm untuk catatan ini juga akan dimatikan.")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Hapus") { _, _ ->
                TaskStore.remove(this, itemId)
                AlarmScheduler.cancel(this, itemId)
                TaskBellWidgetProvider.updateAll(this)
                finish()
            }
            .show()
    }

    private fun showTimePicker() {
        TimePickerDialog(this, { _, selectedHour, selectedMinute ->
            hour = selectedHour
            minute = selectedMinute
            timeButton.text = formatTime()
        }, hour, minute, true).show()
    }

    private fun formatTime(): String = String.format("%02d:%02d", hour, minute)

    private fun fieldLabel(textValue: String): TextView = TextView(this).apply {
        text = textValue
        textSize = 10f
        letterSpacing = 0.08f
        setTextColor(Color.rgb(160, 160, 160))
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(2), 0, 0, dp(8))
    }

    private fun editField(hintValue: String, value: String): EditText = EditText(this).apply {
        setText(value)
        hint = hintValue
        textSize = 14f
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(115, 115, 115))
        setPadding(dp(15), dp(12), dp(15), dp(12))
        background = roundedDrawable(Color.rgb(27, 27, 28), Color.rgb(66, 66, 66), 18)
        imeOptions = EditorInfo.IME_ACTION_NEXT
        setSingleLine(false)
    }

    private fun fieldParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, dp(62)
    ).apply { bottomMargin = dp(17) }

    private fun roundedDrawable(fill: Int, stroke: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
        setStroke(dp(1), stroke)
    }

    private fun tapFeedback(view: View, action: () -> Unit) {
        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        view.animate().cancel()
        view.animate().scaleX(0.975f).scaleY(0.975f).setDuration(75)
            .setInterpolator(AccelerateDecelerateInterpolator()).withEndAction {
                view.animate().scaleX(1f).scaleY(1f).setDuration(115)
                    .setInterpolator(AccelerateDecelerateInterpolator()).withEndAction { action() }.start()
            }.start()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
