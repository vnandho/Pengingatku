package com.pengingatku.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmStopReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_STOP = "com.pengingatku.widget.action.STOP_ALARM"
        const val EXTRA_ITEM_ID = "item_id"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_STOP) return
        val id = intent.getLongExtra(EXTRA_ITEM_ID, 0L)
        if (id == 0L || AlarmRingService.activeItemId == id) {
            context.stopService(Intent(context, AlarmRingService::class.java))
        }
    }
}
