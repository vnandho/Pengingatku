package com.pengingatku.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    companion object {
        const val EXTRA_ITEM_ID = "item_id"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != AlarmScheduler.ACTION_FIRE) return
        val id = intent.getLongExtra(EXTRA_ITEM_ID, 0L)
        if (id == 0L) return
        val item = TaskStore.find(context, id) ?: return
        if (!item.enabled) return

        // Queue the next daily occurrence before starting audio playback.
        AlarmScheduler.schedule(context, item)
        val serviceIntent = Intent(context, AlarmRingService::class.java).apply {
            putExtra(AlarmRingService.EXTRA_ITEM_ID, item.id)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(serviceIntent)
            else context.startService(serviceIntent)
        } catch (_: Exception) {
            // If foreground service startup is blocked, still notify the widget state.
        }
        TaskBellWidgetProvider.updateAll(context)
    }
}
